const express = require("express");
const {
  createUser,
  deleteUser,
  listUsers,
  toggleAvailability,
  updateUser,
} = require("./db");

const app = express();
const port = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: "10kb" }));
app.use(express.static("public"));

function parseUserId(value) {
  if (!/^[1-9]\d*$/.test(value)) {
    return null;
  }

  const id = Number(value);
  return Number.isSafeInteger(id) ? id : null;
}

function validateUser(body) {
  if (!body || typeof body !== "object" || Array.isArray(body)) {
    return "A JSON object is required.";
  }

  if (typeof body.name !== "string" || body.name.trim().length === 0) {
    return "Name is required.";
  }

  if (body.name.trim().length > 100) {
    return "Name must be 100 characters or fewer.";
  }

  if (body.role !== undefined && typeof body.role !== "string") {
    return "Role must be text.";
  }

  if (typeof body.role === "string" && body.role.trim().length > 100) {
    return "Role must be 100 characters or fewer.";
  }

  return null;
}

app.get("/api/users", (request, response) => {
  response.json(listUsers());
});

app.post("/api/users", (request, response) => {
  const validationError = validateUser(request.body);
  if (validationError) {
    return response.status(400).json({ error: validationError });
  }

  const user = createUser(request.body.name.trim(), (request.body.role || "").trim());
  return response.status(201).json(user);
});

app.put("/api/users/:id", (request, response) => {
  const id = parseUserId(request.params.id);
  if (id === null) {
    return response.status(400).json({ error: "A valid user ID is required." });
  }

  const validationError = validateUser(request.body);
  if (validationError) {
    return response.status(400).json({ error: validationError });
  }

  const user = updateUser(
    id,
    request.body.name.trim(),
    (request.body.role || "").trim()
  );

  if (!user) {
    return response.status(404).json({ error: "Team member not found." });
  }

  return response.json(user);
});

app.delete("/api/users/:id", (request, response) => {
  const id = parseUserId(request.params.id);
  if (id === null) {
    return response.status(400).json({ error: "A valid user ID is required." });
  }

  if (!deleteUser(id)) {
    return response.status(404).json({ error: "Team member not found." });
  }

  return response.status(204).end();
});

app.post("/api/users/:id/toggle", (request, response) => {
  const id = parseUserId(request.params.id);
  if (id === null) {
    return response.status(400).json({ error: "A valid user ID is required." });
  }

  const user = toggleAvailability(id);
  if (!user) {
    return response.status(404).json({ error: "Team member not found." });
  }

  return response.json(user);
});

app.use((error, request, response, next) => {
  if (response.headersSent) {
    return next(error);
  }

  if (error instanceof SyntaxError && error.status === 400 && "body" in error) {
    return response.status(400).json({ error: "Request body must be valid JSON." });
  }

  console.error("Request failed:", error);
  return response.status(500).json({ error: "Something went wrong. Please try again." });
});

app.listen(port, () => {
  console.log(`Team Availability Tracker is running at http://localhost:${port}`);
});
