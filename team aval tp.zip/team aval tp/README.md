# Team Availability Tracker

A simple full-stack dashboard for checking and managing team availability. The frontend is built with HTML, CSS, and vanilla JavaScript; an Express REST API reads and writes team members in a local SQLite database.

## Objectives

- View team members and their roles in one place.
- Check who's available and who's busy.
- Update availability and manage member records without reloading the dashboard.
- Demonstrate frontend, REST API, backend, and persistent database integration.

## Features

- Summary cards for total, available, and busy team members.
- Search members by name or role.
- Filter the list by all, available, or busy members.
- Add and edit member names and roles.
- Delete members after confirmation.
- Toggle availability between available and busy.
- Responsive layout, loading/error states, empty states, and success/error feedback.
- Safe text rendering and server-side input validation.
- SQLite initialization and demo data seeding on first run.

## Technologies

- HTML5, CSS3, and vanilla JavaScript
- Fetch API
- Node.js and Express
- SQLite via Node.js's built-in `node:sqlite` module

## Project structure

```text
Team-Availability-Tracker/
├── public/
│   ├── index.html
│   ├── styles.css
│   └── app.js
├── server.js
├── db.js
├── package.json
├── README.md
└── data.db                 # Created automatically on first run
```

## Requirements

- Node.js 22.13.0 or newer (for the built-in `node:sqlite` module)
- npm

No separate SQLite installation is required.

## Install and run

From the project directory:

```bash
npm install
npm start
```

Open [http://localhost:3000](http://localhost:3000). Set the `PORT` environment variable to use a different port.

The SQLite database is created as `data.db` in the project directory when the server starts. Five sample members are inserted only if the `users` table is empty. Changes persist across server restarts.

## REST API

All API responses use JSON except for the successful delete response, which has an empty `204 No Content` body.

| Method | Endpoint | Description |
| --- | --- | --- |
| `GET` | `/api/users` | List all team members |
| `POST` | `/api/users` | Create a member with `{"name":"Alex Rivers","role":"Developer"}` |
| `PUT` | `/api/users/:id` | Update a member with `{"name":"Alex Rivers","role":"Developer"}` |
| `DELETE` | `/api/users/:id` | Delete a member |
| `POST` | `/api/users/:id/toggle` | Toggle a member's availability |

Each user has an integer `id`, a `name`, a `role`, and an `available` boolean in API responses. The database stores availability as `1` or `0`.

Typical status codes include `200` for successful reads/updates, `201` for creation, `204` for deletion, `400` for invalid input, and `404` when a member does not exist. Unexpected server errors return a generic message rather than database details.

## Database

`db.js` opens the local SQLite file, creates the `users` table if needed, and seeds sample members only when the table has no records. SQL operations are kept outside the Express route handlers. The `users` table contains:

```sql
id INTEGER PRIMARY KEY AUTOINCREMENT,
name TEXT NOT NULL,
role TEXT,
available INTEGER DEFAULT 1
```

## Future enhancements

- Add teams and workspace-level organization.
- Add authentication and role-based permissions.
- Add availability scheduling and status history.
- Add pagination and server-side search for larger teams.
