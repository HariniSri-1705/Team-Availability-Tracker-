const memberList = document.querySelector("#member-list");
const memberSearch = document.querySelector("#member-search");
const memberDialog = document.querySelector("#member-dialog");
const memberForm = document.querySelector("#member-form");
const toastRegion = document.querySelector("#toast-region");

let members = [];
let currentFilter = "all";
let editingMemberId = null;
let toastTimeout;

document.querySelector("#today-label").textContent = new Intl.DateTimeFormat("en", {
  weekday: "short",
  month: "short",
  day: "numeric",
}).format(new Date());
document.querySelector("#current-year").textContent = new Date().getFullYear();

async function requestJson(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: {
      ...(options.body ? { "Content-Type": "application/json" } : {}),
      ...options.headers,
    },
  });

  if (response.status === 204) {
    return null;
  }

  const data = await response.json().catch(() => null);
  if (!response.ok) {
    throw new Error(data?.error || "The request could not be completed.");
  }

  return data;
}

function showToast(message, type = "success") {
  window.clearTimeout(toastTimeout);
  toastRegion.replaceChildren();

  const toast = document.createElement("div");
  toast.className = `toast toast-${type}`;
  toast.textContent = message;
  toastRegion.append(toast);
  toastTimeout = window.setTimeout(() => toast.remove(), 3600);
}

function setLoading(isLoading) {
  memberList.setAttribute("aria-busy", String(isLoading));
}

function updateSummary() {
  const availableCount = members.filter((member) => member.available).length;
  document.querySelector("#total-count").textContent = members.length;
  document.querySelector("#available-count").textContent = availableCount;
  document.querySelector("#busy-count").textContent = members.length - availableCount;
  document.querySelector("#member-count-label").textContent =
    `${members.length} ${members.length === 1 ? "member" : "members"}`;
}

function initialsFor(name) {
  return name
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part.charAt(0))
    .join("")
    .toUpperCase();
}

function createIconButton(label, iconName, memberId) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = `icon-button ${iconName}-button`;
  button.setAttribute("aria-label", `${label} ${members.find((member) => member.id === memberId)?.name || "team member"}`);
  button.dataset.action = iconName;
  button.dataset.id = memberId;

  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("viewBox", "0 0 20 20");
  svg.setAttribute("aria-hidden", "true");
  const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
  path.setAttribute(
    "d",
    iconName === "edit"
      ? "m13.8 4.2 2 2M4 16l3.6-.7L16 6.9a1.4 1.4 0 0 0-2-2l-8.4 8.4L4 16Z"
      : "M5 6h10m-9 0 .7 10h6.6L14 6m-6-2h4l1 2m-4 3v5m3-5v5"
  );
  svg.append(path);
  button.append(svg);
  return button;
}

function createMemberRow(member) {
  const row = document.createElement("article");
  row.className = "member-row";

  const identity = document.createElement("div");
  identity.className = "member-identity";
  const avatar = document.createElement("span");
  avatar.className = `member-avatar avatar-${member.id % 5}`;
  avatar.textContent = initialsFor(member.name);
  avatar.setAttribute("aria-hidden", "true");
  const text = document.createElement("div");
  text.className = "member-copy";
  const name = document.createElement("span");
  name.className = "member-name";
  name.textContent = member.name;
  const role = document.createElement("span");
  role.className = "member-role";
  role.textContent = member.role || "No role specified";
  text.append(name, role);
  identity.append(avatar, text);

  const statusCell = document.createElement("div");
  statusCell.className = "member-status-cell";
  const badge = document.createElement("span");
  badge.className = `status-badge ${member.available ? "status-available" : "status-busy"}`;
  const statusDot = document.createElement("span");
  statusDot.className = "status-dot";
  const statusText = document.createElement("span");
  statusText.textContent = member.available ? "Available" : "Busy";
  badge.append(statusDot, statusText);
  statusCell.append(badge);

  const toggleCell = document.createElement("div");
  toggleCell.className = "member-toggle-cell";
  const toggleButton = document.createElement("button");
  toggleButton.type = "button";
  toggleButton.className = `button button-status ${member.available ? "make-busy" : "make-available"}`;
  toggleButton.dataset.action = "toggle";
  toggleButton.dataset.id = member.id;
  toggleButton.textContent = member.available ? "Set busy" : "Set available";
  toggleButton.setAttribute("aria-label", `${toggleButton.textContent}: ${member.name}`);
  toggleCell.append(toggleButton);

  const actions = document.createElement("div");
  actions.className = "member-actions";
  actions.append(createIconButton("Edit", "edit", member.id), createIconButton("Delete", "delete", member.id));

  row.append(identity, statusCell, toggleCell, actions);
  return row;
}

function renderMembers() {
  const query = memberSearch.value.trim().toLocaleLowerCase();
  const filteredMembers = members.filter((member) => {
    const matchesSearch = `${member.name} ${member.role || ""}`.toLocaleLowerCase().includes(query);
    const matchesFilter =
      currentFilter === "all" ||
      (currentFilter === "available" && member.available) ||
      (currentFilter === "busy" && !member.available);
    return matchesSearch && matchesFilter;
  });

  memberList.replaceChildren();
  if (filteredMembers.length === 0) {
    const emptyState = document.createElement("div");
    emptyState.className = "empty-state";
    const heading = document.createElement("strong");
    heading.textContent = members.length === 0 ? "Your team is just getting started" : "No members found";
    const message = document.createElement("span");
    message.textContent =
      members.length === 0
        ? "Add your first team member to see availability here."
        : "Try another search or availability filter.";
    emptyState.append(heading, message);
    if (members.length === 0) {
      const addButton = document.createElement("button");
      addButton.type = "button";
      addButton.className = "button button-primary";
      addButton.textContent = "Add your first member";
      addButton.addEventListener("click", openAddDialog);
      emptyState.append(addButton);
    }
    memberList.append(emptyState);
  } else {
    const rows = document.createDocumentFragment();
    for (const member of filteredMembers) {
      rows.append(createMemberRow(member));
    }
    memberList.append(rows);
  }

  setLoading(false);
  updateSummary();
}

async function loadMembers() {
  setLoading(true);
  try {
    members = await requestJson("/api/users");
    renderMembers();
  } catch (error) {
    memberList.replaceChildren();
    const errorState = document.createElement("div");
    errorState.className = "error-state";
    const message = document.createElement("p");
    message.textContent = error.message;
    const retryButton = document.createElement("button");
    retryButton.type = "button";
    retryButton.className = "button button-secondary";
    retryButton.textContent = "Try again";
    retryButton.addEventListener("click", loadMembers);
    errorState.append(message, retryButton);
    memberList.append(errorState);
    document.querySelector("#member-count-label").textContent = "Unable to load";
    setLoading(false);
  }
}

function openAddDialog() {
  editingMemberId = null;
  memberForm.reset();
  document.querySelector("#dialog-title").textContent = "Add a member";
  document.querySelector("#dialog-description").textContent = "Add someone new to your workspace.";
  document.querySelector("#save-member-button").textContent = "Add member";
  memberDialog.showModal();
  document.querySelector("#member-name").focus();
}

function openEditDialog(member) {
  editingMemberId = member.id;
  memberForm.elements.name.value = member.name;
  memberForm.elements.role.value = member.role || "";
  document.querySelector("#dialog-title").textContent = "Edit member";
  document.querySelector("#dialog-description").textContent = "Update this team member's details.";
  document.querySelector("#save-member-button").textContent = "Save changes";
  memberDialog.showModal();
  document.querySelector("#member-name").focus();
}

async function saveMember(event) {
  event.preventDefault();
  if (!memberForm.reportValidity()) {
    return;
  }

  const saveButton = document.querySelector("#save-member-button");
  saveButton.disabled = true;
  const memberData = {
    name: memberForm.elements.name.value.trim(),
    role: memberForm.elements.role.value.trim(),
  };

  try {
    if (editingMemberId === null) {
      await requestJson("/api/users", {
        method: "POST",
        body: JSON.stringify(memberData),
      });
      showToast(`${memberData.name} was added to your team.`);
    } else {
      await requestJson(`/api/users/${editingMemberId}`, {
        method: "PUT",
        body: JSON.stringify(memberData),
      });
      showToast("Team member details were updated.");
    }
    memberDialog.close();
    await loadMembers();
  } catch (error) {
    showToast(error.message, "error");
  } finally {
    saveButton.disabled = false;
  }
}

async function handleMemberAction(event) {
  const button = event.target.closest("button[data-action]");
  if (!button) {
    return;
  }

  const memberId = Number(button.dataset.id);
  const member = members.find((item) => item.id === memberId);
  if (!member) {
    return;
  }

  if (button.dataset.action === "edit") {
    openEditDialog(member);
    return;
  }

  if (button.dataset.action === "delete") {
    if (!window.confirm(`Delete ${member.name} from your team? This cannot be undone.`)) {
      return;
    }

    button.disabled = true;
    try {
      await requestJson(`/api/users/${memberId}`, { method: "DELETE" });
      showToast(`${member.name} was removed from your team.`);
      await loadMembers();
    } catch (error) {
      button.disabled = false;
      showToast(error.message, "error");
    }
    return;
  }

  if (button.dataset.action === "toggle") {
    button.disabled = true;
    try {
      const updatedMember = await requestJson(`/api/users/${memberId}/toggle`, {
        method: "POST",
      });
      members = members.map((item) => (item.id === memberId ? updatedMember : item));
      renderMembers();
      showToast(`${member.name} is now ${updatedMember.available ? "available" : "busy"}.`);
    } catch (error) {
      button.disabled = false;
      showToast(error.message, "error");
    }
  }
}

document.querySelector("#add-member-button").addEventListener("click", openAddDialog);
memberForm.addEventListener("submit", saveMember);
memberList.addEventListener("click", handleMemberAction);
memberSearch.addEventListener("input", renderMembers);
document.querySelectorAll(".filter-button").forEach((button) => {
  button.addEventListener("click", () => {
    currentFilter = button.dataset.filter;
    document.querySelectorAll(".filter-button").forEach((filterButton) => {
      const isSelected = filterButton === button;
      filterButton.classList.toggle("selected", isSelected);
      filterButton.setAttribute("aria-pressed", String(isSelected));
    });
    renderMembers();
  });
});
document.querySelector("#close-dialog-button").addEventListener("click", () => memberDialog.close());
document.querySelector("#cancel-dialog-button").addEventListener("click", () => memberDialog.close());
memberDialog.addEventListener("click", (event) => {
  if (event.target === memberDialog) {
    memberDialog.close();
  }
});
document.addEventListener("keydown", (event) => {
  if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
    event.preventDefault();
    memberSearch.focus();
  }
});

loadMembers();
