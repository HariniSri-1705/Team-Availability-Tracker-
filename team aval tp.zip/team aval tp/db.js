const path = require("node:path");
const { DatabaseSync } = require("node:sqlite");

const database = new DatabaseSync(path.join(__dirname, "data.db"));

database.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    role TEXT,
    available INTEGER DEFAULT 1
  )
`);

const count = database.prepare("SELECT COUNT(*) AS count FROM users").get();

if (count.count === 0) {
  const addUser = database.prepare(
    "INSERT INTO users (name, role, available) VALUES (?, ?, ?)"
  );
  const demoUsers = [
    ["Alex Rivers", "Senior Developer", 1],
    ["Samantha Chen", "UX Designer", 1],
    ["Jordan Taylor", "Project Manager", 0],
    ["Maria Garcia", "Marketing Lead", 1],
    ["Chris Patel", "QA Engineer", 0],
  ];

  database.exec("BEGIN");
  try {
    for (const user of demoUsers) {
      addUser.run(...user);
    }
    database.exec("COMMIT");
  } catch (error) {
    database.exec("ROLLBACK");
    throw error;
  }
}

function listUsers() {
  return database
    .prepare("SELECT id, name, role, available FROM users ORDER BY id")
    .all()
    .map((user) => ({
      ...user,
      available: Boolean(user.available),
    }));
}

function findUser(id) {
  const user = database
    .prepare("SELECT id, name, role, available FROM users WHERE id = ?")
    .get(id);

  return user ? { ...user, available: Boolean(user.available) } : null;
}

function createUser(name, role) {
  const result = database
    .prepare("INSERT INTO users (name, role) VALUES (?, ?)")
    .run(name, role);

  return findUser(Number(result.lastInsertRowid));
}

function updateUser(id, name, role) {
  const result = database
    .prepare("UPDATE users SET name = ?, role = ? WHERE id = ?")
    .run(name, role, id);

  return result.changes > 0 ? findUser(id) : null;
}

function deleteUser(id) {
  return database.prepare("DELETE FROM users WHERE id = ?").run(id).changes > 0;
}

function toggleAvailability(id) {
  const result = database
    .prepare("UPDATE users SET available = CASE available WHEN 1 THEN 0 ELSE 1 END WHERE id = ?")
    .run(id);

  return result.changes > 0 ? findUser(id) : null;
}

module.exports = {
  createUser,
  deleteUser,
  findUser,
  listUsers,
  toggleAvailability,
  updateUser,
};
